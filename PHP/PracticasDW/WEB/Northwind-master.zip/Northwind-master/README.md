Es un pequeño proyecto que recolecta información de una base de datos a modo de demo que se usaba hace algunos años por parte de Microsoft, no es la gran cosa, pero sirver para iniciarse en el mundo de las consultas o en mi caso para mostrar algunos cosas en las aplicaciones que muestro en mi canal de [youtube](http://youtube.com/nayosx)

Los scripts fueron sacados de [northwindextended](https://code.google.com/archive/p/northwindextended/downloads) y se modifico el de MySQL (es el que mas uso y me dio problemas al tratar de ejecutarlo en workbeanch)

Agradecimientos especiales para [aspsnippets](http://www.aspsnippets.com/Articles/Download-and-Install-Microsoft-Northwind-Sample-database-in-MySql.aspx) de no ser por ellos no hubiera tenido acceso a los scripts

Espero a mas de alguno le sea de utilidad.

# English version

It is a small project that collects information from a database as a demo that was used several years ago by Microsoft, it's not a big deal, but beofre to enter the world of consultations or in my case to show some applications things I show in my channel [youtube](http://youtube.com/nayosx)

The scripts were taken from [northwindextended](https://code.google.com/archive/p/northwindextended/downloads) and modify the MySQL (the ones I use and gave me problems when trying to run it on workbeanch)

Special thanks to [aspsnippets](http://www.aspsnippets.com/Articles/Download-and-Install-Microsoft-Northwind-Sample-database-in-MySql.aspx) not for them I would not have access to scripts

I hope to more than one is helpful

