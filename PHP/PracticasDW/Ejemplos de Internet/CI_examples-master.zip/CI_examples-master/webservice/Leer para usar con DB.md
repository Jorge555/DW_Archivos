Este proyecto funciona correctamente con la siguiente base de datos 

https://github.com/nayosx/Northwind

Se usa la de Mysql 5 NoPhotos