# CI_examples
Pequeños proyectos hechos con el framework Codeigniter
