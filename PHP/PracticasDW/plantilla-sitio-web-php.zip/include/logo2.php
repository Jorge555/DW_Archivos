<?php 
echo '<div id="bar"><a style="color:white;text-decoration:none;" href="http://misitio/index.php"><b>Mi Sitio web</b></a><div style="clear:both;font-size:0.5em;margin:8px 0 -4px 0;color:white;">Actualidad y tecnologia</div></div>';
?> 