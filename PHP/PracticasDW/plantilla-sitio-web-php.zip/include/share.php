<?php 
echo '<h3>S�guenos en las redes sociales</h3><a href="http://www.facebook.com/"><img src="img/logo-facebook.jpg" width="96" height="96" alt="S�guenos en Facebook" title="S�guenos en Facebook"></a>
<a href="https://twitter.com/"><img src="img/logo-twitter.jpg" width="96" height="96" alt="S�guenos en Twitter" title="S�guenos en Twitter"></a>
<a href="https://plus.google.com/"><img src="img/logo-google-plus.jpg" width="96" height="96" alt="S�guenos en Google+" title="S�guenos en Google+"></a>';
?> 