<?php 
echo '<img src="img/misitio.jpg" width="700" height="120" alt="Mi sitio" title="Mi sitio web">';
?> 