<?php 
echo '<div style="text-align:center;padding:6px;"><a href="#inicio">Subir</a></div>
<div class="footer">
Copyright &copy; 2014 Mi Nombre<br>
</div><br>';
?> 
